package sidescroller.scene;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.canvas.Canvas;
import sidescroller.animator.AnimatorInterface;
import sidescroller.entity.GenericEntity;
import sidescroller.entity.property.Entity;
import sidescroller.entity.property.HitBox;
import sidescroller.entity.sprite.SpriteFactory;
import sidescroller.entity.sprite.tile.*;
import utility.Tuple;

public class MapScene implements MapSceneInterface {

	private Tuple count;
	private Tuple size;
	private double scale;
	private AnimatorInterface animator;
	private List<Entity> players;
	private List<Entity> staticShapes;
	private BooleanProperty drawBounds;
	private BooleanProperty drawFPS;
	private BooleanProperty drawGrid;
	private Entity background;

	// Initialize the lists and BooleanProperties inside of the constructor.
	// to initialize a BooleanProperties use the class SimpleBooleanProperty.
	public MapScene() {
		players = new ArrayList<>();
		staticShapes = new ArrayList<>();
		drawBounds = new SimpleBooleanProperty();
		drawFPS = new SimpleBooleanProperty();
		drawGrid = new SimpleBooleanProperty();
	}

	/**
	 * @return the drawFPS instance.
	 */
	@Override
	public BooleanProperty drawFPSProperty() {
		return drawFPS;
	}

	/**
	 * @return the value of {@link BooleanProperty#get()}
	 */
	@Override
	public boolean getDrawFPS() {
		return drawFPS.get();
	}

	/**
	 * @return the drawBounds instance.
	 */
	@Override
	public BooleanProperty drawBoundsProperty() {
		return drawBounds;
	}

	/**
	 * @return the value of {@link BooleanProperty#get()}
	 */
	@Override
	public boolean getDrawBounds() {
		return drawBounds.get();
	}

	/**
	 * @return the drawGrid instance.
	 */
	@Override
	public BooleanProperty drawGridProperty() {
		return drawGrid;
	}

	/**
	 * @return the value of {@link BooleanProperty#get()}
	 */
	@Override
	public boolean getDrawGrid() {
		return drawGrid.get();
	}

	/**
	 * save data in the correct variables.
	 * 
	 * @param count - number of rows and columns in the grid.
	 * @param size  - width and height of each cell in grid.
	 * @param scale - a double multiplier for width and height of each grid cell.
	 * @return current instance of this class.
	 */
	@Override
	public MapScene setRowAndCol(Tuple count, Tuple size, double scale) {
		this.count = count;
		this.size = size;
		this.scale = scale;

		return this;
	}

	/**
	 * @return count variable.
	 */
	@Override
	public Tuple getGridCount() {
		return count;
	}

	/**
	 * @return size variable.
	 */
	@Override
	public Tuple getGridSize() {
		return size;
	}

	/**
	 * @return scale variable.
	 */
	@Override
	public double getScale() {
		return scale;
	}

	/**
	 * 
	 * @param newAnimator - new animator to set.
	 * @return current instance of this class.
	 * @throws NullPointerException if argument is null.
	 */
	@Override
	public MapScene setAnimator(AnimatorInterface newAnimator) throws NullPointerException {

		// if current animator instance is not null stop it first.
		if (animator != null)
			animator.stop();

		if (newAnimator == null)
			throw new NullPointerException();

		// then assign the newAnimator to animator.
		animator = newAnimator;
		return this;
	}

	/**
	 * @return get background entity.
	 */
	@Override
	public Entity getBackground() {
		return background;
	}

	/**
	 * if animator is not null start animator.
	 */
	@Override
	public void start() {
		if (animator != null)
			animator.start();
	}

	/**
	 * if animator is not null stop animator.
	 */
	@Override
	public void stop() {
		if (animator != null)
			animator.stop();
	}

	/**
	 * @return static list. this list will hold all entities short of background,
	 *         player, and any Entity that moves.
	 */
	@Override
	public List<Entity> staticShapes() {
		return staticShapes;
	}

	/**
	 * @return players list.
	 */
	@Override
	public List<Entity> players() {
		return players;
	}

	/**
	 * this method creates the static entities in the game.
	 * 
	 * @param canvas
	 * @return
	 */
	@Override
	public MapScene createScene(Canvas canvas) {
		// use {@link MapBuilder#createBuilder()} to get and instance of MapBuilder
		// called mb.
		MapBuilder mb = MapBuilder.createBuilder();

		// on mb call methods {@link MapBuilder#setCanvas(Canvas)}, {@link
		// MapBuilder#setGrid(Tuple, Tuple)}, and {@link
		// MapBuilder#setGridScale(double)}.
		mb.setCanvas(canvas);
		mb.setGrid(count, size);
		mb.setGridScale(scale);

		// call all or any combination of build methods in MapBuilder to create custom
		// map, does not have to be complex. one landmass and a tree is good enough.
		BiFunction<Integer, Integer, Tile> callback = (row, col) -> {
			if (row < 8 && Math.random() > .88)
				return BackgroundTile.NIGHT_CLOUD;
			return BackgroundTile.NIGHT;
		};
		mb.buildBackground(callback);
		mb.buildPlatform(7, 14, 6, PlatformTile.WOOD);
		mb.buildLandMass(10, 4, 4, 9);
		mb.buildLandMass(10, 21, 4, 10);
		mb.buildLandMass(12, 13, 2, 8);
		mb.buildTree(5, 5, FloraTile.TREE_DEAD);
		mb.buildTree(5,24, FloraTile.TREE_DEAD);
		mb.buildTree(9, 26, FloraTile.BUSH);
		mb.buildTree(9, 27, FloraTile.BUSH);
		mb.buildTree(9, 28, FloraTile.BUSH);
		mb.buildTree(9, 25, FloraTile.BUSH);
		mb.buildTree(9, 8, ItemTile.SIGN);
		mb.buildTree(9, 6, FloraTile.FLOWER_PURPLE);
		mb.buildTree(9, 7, FloraTile.FLOWER_PURPLE);
		

		// call {@link MapBuilder#getBackground()} and {@link
		// MapBuilder#getEntities(List)} to retrieve the built entities.
		background = mb.getBackground();
		mb.getEntities(staticShapes());

		return this;
	}

	/**
	 * @param hitbox - hitbox of an entity to check it is it still in background
	 *               bounds.
	 * @return true of hitbox of background containsBouns of argument.
	 */
	@Override
	public boolean inMap(HitBox hitbox) {
		return background.getHitBox().containsBounds(hitbox);
	}

}
