Credit goes to The Mighty Palm

Made in PyxelEdit(Full Version)

Designed with Will Lewis's Platformer Engine for GMS2 in mind, but can be used any way you like.